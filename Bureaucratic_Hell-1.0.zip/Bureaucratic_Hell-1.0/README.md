# Bureaucratic_Hell
This game will ruin your thought of easily running a country.
***
## Notes
- Free to play
- Anoying to play
Made by @SYOP200 
***
## Download
- You can download Bureaucratic Hell from the files above or clicking this [link](https://github.com/user-attachments/files/23391401/bureaucratic-hell.html)

***
## Licensing
GNU
- Distribution of the game is herby ALLOWED to all users. Users may NOT change the code and/or personalize the game.
***
### Thank You for supporting game development!

